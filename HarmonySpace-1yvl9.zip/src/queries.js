import { HttpError } from 'wasp/server'

export const getProjects = async (arg, context) => {
  if (!context.user) { throw new HttpError(401) };

  return context.entities.Project.findMany({
    where: { userId: context.user.id },
    include: { designs: true }
  });
}

export const getDesign = async (arg, context) => {
  if (!context.user) { throw new HttpError(401) }

  const design = await context.entities.Design.findUnique({
    where: { id: arg.designId },
    include: { project: true }
  });

  if (!design) { throw new HttpError(404, 'No design found with id ' + arg.designId) }

  const user = await context.entities.User.findUnique({
    where: { id: context.user.id },
    include: { projects: { include: { designs: true } } }
  });

  if (!user || !user.projects.find(project => project.id === design.projectId)) {
    throw new HttpError(400, 'Design does not belong to the authenticated user')
  }

  return design;
}