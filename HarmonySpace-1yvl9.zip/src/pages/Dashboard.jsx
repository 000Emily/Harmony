import React from 'react';
import { Link } from 'react-router-dom';
import { useQuery, useAction, getProjects, createProject } from 'wasp/client/operations';

const DashboardPage = () => {
  const { data: projects, isLoading, error } = useQuery(getProjects);
  const createProjectFn = useAction(createProject);
  const [newProjectName, setNewProjectName] = React.useState('');

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  const handleCreateProject = () => {
    createProjectFn({ name: newProjectName });
    setNewProjectName('');
  };

  return (
    <div className='p-4'>
      <div className='mb-4'>
        <input
          type='text'
          placeholder='New Project'
          className='px-2 py-1 border rounded'
          value={newProjectName}
          onChange={(e) => setNewProjectName(e.target.value)}
        />
        <button
          onClick={handleCreateProject}
          className='bg-green-500 hover:bg-green-700 text-white font-bold py-1 px-2 rounded ml-2'
        >
          Create Project
        </button>
      </div>
      {projects.map((project) => (
        <div key={project.id} className='bg-gray-100 p-4 mb-4 rounded-lg'>
          <div>{project.name}</div>
          <Link to={`/project/${project.id}`} className='bg-blue-500 hover:bg-blue-700 text-white font-bold py-1 px-2 rounded'>Details</Link>
        </div>
      ))}
    </div>
  );
}

export default DashboardPage;