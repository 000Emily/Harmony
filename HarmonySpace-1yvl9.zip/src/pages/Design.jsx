import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useQuery, useAction, getDesign, updateDesign } from 'wasp/client/operations';

const DesignPage = () => {
  const { designId } = useParams();
  const { data: design, isLoading, error } = useQuery(getDesign, { designId });
  const updateDesignFn = useAction(updateDesign);
  const [newDescription, setNewDescription] = useState('');

  useEffect(() => {
    if (design) {
      setNewDescription(design.description);
    }
  }, [design]);

  const handleUpdateDesign = () => {
    updateDesignFn({ designId, description: newDescription });
  };

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  return (
    <div className='p-4'>
      <h1 className='text-2xl font-bold'>{design.name}</h1>
      <p className='text-gray-600 my-2'>{design.description}</p>
      <textarea
        value={newDescription}
        onChange={(e) => setNewDescription(e.target.value)}
        className='border rounded p-2 w-full my-2'
      ></textarea>
      <button
        onClick={handleUpdateDesign}
        className='bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded'
      >
        Update Design
      </button>
    </div>
  );
}

export default DesignPage;