import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { useQuery, useAction, getProjects, createDesign, updateDesign } from 'wasp/client/operations';

const ProjectPage = () => {
  const { projectId } = useParams();
  const { data: projects, isLoading, error } = useQuery(getProjects);
  const createDesignFn = useAction(createDesign);
  const updateDesignFn = useAction(updateDesign);
  const [newDesignName, setNewDesignName] = useState('');
  const [newDesignDescription, setNewDesignDescription] = useState('');

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  const handleCreateDesign = () => {
    createDesignFn({ name: newDesignName, description: newDesignDescription, projectId: parseInt(projectId) });
    setNewDesignName('');
    setNewDesignDescription('');
  };

  return (
    <div className='p-4'>
      {projects.map((project) => {
        if (project.id === parseInt(projectId)) {
          return (
            <div key={project.id} className='bg-gray-100 p-4 mb-4 rounded-lg'>
              <h2 className='text-2xl font-semibold'>{project.name}</h2>
              <div className='mb-4'>
                <input
                  type='text'
                  placeholder='New Design Name'
                  className='px-1 py-2 border rounded text-lg'
                  value={newDesignName}
                  onChange={(e) => setNewDesignName(e.target.value)}
                />
                <textarea
                  placeholder='New Design Description'
                  className='px-1 py-2 border rounded text-lg mt-2'
                  value={newDesignDescription}
                  onChange={(e) => setNewDesignDescription(e.target.value)}
                ></textarea>
                <button
                  onClick={handleCreateDesign}
                  className='bg-blue-500 hover:bg-blue-700 px-2 py-2 text-white font-bold rounded mt-2'
                >
                  Add Design
                </button>
              </div>
              {project.designs.map((design) => (
                <div key={design.id} className='bg-white p-4 mb-4 rounded-lg'>
                  <h3 className='text-lg font-semibold'>{design.name}</h3>
                  <p>{design.description}</p>
                  <button
                    onClick={() => updateDesignFn({ designId: design.id, newDescription: 'Updated Description' })}
                    className='bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded mt-2'
                  >
                    Update Description
                  </button>
                </div>
              ))}
            </div>
          );
        }
        return null;
      })}
    </div>
  );
}

export default ProjectPage;