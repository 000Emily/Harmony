import { HttpError } from 'wasp/server'

export const createProject = async (args, context) => {
  if (!context.user) { throw new HttpError(401) }
  return context.entities.Project.create({
    data: {
      userId: context.user.id
    }
  })
}

export const createDesign = async (args, context) => {
  if (!context.user) { throw new HttpError(401) }
  const newDesign = await context.entities.Design.create({
    data: {
      name: args.name,
      description: args.description,
      project: {
        connect: { id: args.projectId }
      }
    }
  })
  return newDesign
}

export const updateDesign = async (args, context) => {
  if (!context.user) { throw new HttpError(401) }
  const design = await context.entities.Design.findUnique({
    where: { id: args.designId }
  })
  if (design.project.userId !== context.user.id) { throw new HttpError(403) }
  return context.entities.Design.update({
    where: { id: args.designId },
    data: { description: args.newDescription }
  })
}